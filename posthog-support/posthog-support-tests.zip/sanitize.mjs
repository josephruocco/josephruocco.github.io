const allowed = new Set(['token', 'distinct_id', '$process_person_profile', '$set', '$set_once', '$unset', '$lib', '$lib_version', 'run_id', 'case_id', 'synthetic_pii', 'keep', '$anon_distinct_id', '$user_id', '$device_id']);
const personKeys = new Set(['synthetic_pii', 'keep']);

export function syntheticOnly(event, runId) {
  event.properties = Object.fromEntries(Object.entries(event.properties).filter(([key]) => allowed.has(key)));
  for (const target of [event, event.properties]) {
    for (const key of ['$set', '$set_once']) {
      if (target[key]) target[key] = Object.fromEntries(Object.entries(target[key]).filter(([name]) => personKeys.has(name)));
    }
  }
  event.properties.$ip = '127.0.0.1';
  event.properties.$geoip_disable = true;
  event.properties.run_id = runId;
  return event;
}
