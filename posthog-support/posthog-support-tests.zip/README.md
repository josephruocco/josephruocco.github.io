# PostHog support verification

Pinned posthog-js 1.444.3 and 1.444.4. Seventeen tests execute the actual browser SDK in JSDOM with controlled clocks and mocked HTTP. A separate Python zoneinfo check independently verifies the 16 synthetic timestamps.

```sh
npm ci --no-audit --no-fund
npm test
node evidence.mjs
python3 verify-reference.py
```

The original run used Node 26.7.0, npm 11.19.0, and Python 3.9.6. The lockfile pins the resolved dependencies; evidence.json records exact SDK artifact hashes and timezone runtime metadata. No project token or cloud access is required. These are local checks, not a PostHog ingestion or deletion emulator.

The four-complete-week reference interval is October 5, 2026 at 00:00 America/New_York through November 2, 2026 at 00:00 America/New_York, exclusive. The expected weekday totals for that interval are Friday 1, Saturday 2, Sunday 4.

The live findings, recording checkpoints, and limitations are documented at https://josephruocco.net/posthog-support/.
