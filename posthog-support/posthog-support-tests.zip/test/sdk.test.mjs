import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { JSDOM, VirtualConsole } from 'jsdom';
import { cases, weekday, counts } from '../weekday-data.mjs';
import { syntheticOnly } from '../sanitize.mjs';

const require = createRequire(import.meta.url);

test('synthetic sanitizer preserves SDK transport requirements and removes automatic person metadata', () => {
  const event = syntheticOnly({ event: 'synthetic_test', properties: { token: 'phc_SYNTHETIC', distinct_id: 'synthetic', $current_url: 'private', $set: { synthetic_pii: 'FAKE', email: 'private' } }, $set_once: { $initial_current_url: 'private', keep: 'KEEP' } }, 'synthetic-run');
  assert.equal(event.properties.token, 'phc_SYNTHETIC');
  assert.equal(event.properties.$current_url, undefined);
  assert.deepEqual(event.properties.$set, { synthetic_pii: 'FAKE' });
  assert.deepEqual(event.$set_once, { keep: 'KEEP' });
  assert.equal(event.properties.$ip, '127.0.0.1');
});

function browser(packageName, config = {}, stored = {}) {
  const dom = new JSDOM('<!doctype html><html><head></head><body></body></html>', {
    url: 'https://synthetic.example.test/', runScripts: 'outside-only', virtualConsole: new VirtualConsole(),
  });
  const window = dom.window;
  let now = 1793660400000;
  const NativeDate = window.Date;
  window.Date = class extends NativeDate {
    constructor(...args) { super(...(args.length ? args : [now])); }
    static now() { return now; }
  };
  window.XMLHttpRequest = class {
    withCredentials = true;
    open() {}
    setRequestHeader() {}
    send() {}
    abort() {}
  };
  window.fetch = async () => { throw new Error('Network forbidden in local tests'); };
  Object.entries(stored).forEach(([key, value]) => window.localStorage.setItem(key, value));
  window.eval(readFileSync(require.resolve(`${packageName}/dist/array.no-external.js`), 'utf8'));
  const seen = [];
  const sdk = window.posthog.init('phc_SYNTHETIC_LOCAL_ONLY', {
    api_host: 'https://ingestion.example.test',
    autocapture: false, capture_pageview: false, capture_pageleave: false,
    disable_session_recording: true, disable_surveys: true, disable_external_dependency_loading: true,
    advanced_disable_flags: true, advanced_disable_decide: true,
    capture_performance: false, capture_exceptions: false,
    opt_out_useragent_filter: true, persistence: 'localStorage',
    save_campaign_params: false, save_referrer: false,
    before_send: event => { seen.push(JSON.parse(JSON.stringify(event))); return event; },
    ...config,
  });
  return { sdk, seen, window, advance: milliseconds => { now += milliseconds; }, close: () => dom.window.close() };
}

test('weekday reference cases cover local midnight, spring gap and repeated fall hour', () => {
  for (const [timestamp, localDate, expectedNY, expectedUTC] of cases) {
    assert.equal(weekday(timestamp, 'America/New_York'), expectedNY, timestamp);
    assert.equal(weekday(timestamp, 'UTC'), expectedUTC, timestamp);
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(timestamp));
    assert.equal(parts, localDate);
  }
  assert.deepEqual(counts('America/New_York'), [2, 0, 0, 0, 2, 4, 8]);
  assert.deepEqual(counts('UTC'), [4, 0, 0, 0, 0, 4, 8]);
});

test('four complete New York weeks ending November 2 contain Friday 1, Saturday 2, Sunday 4', () => {
  const start = Date.parse('2026-10-05T00:00:00-04:00');
  const end = Date.parse('2026-11-02T00:00:00-05:00');
  const totals = [0, 0, 0, 0, 0, 0, 0];
  for (const [timestamp] of cases) {
    if (Date.parse(timestamp) >= start && Date.parse(timestamp) < end) totals[weekday(timestamp, 'America/New_York') - 1]++;
  }
  assert.deepEqual(totals, [0, 0, 0, 0, 1, 2, 4]);
});

for (const packageName of ['posthog-js', 'posthog-js-previous']) {
  const version = require(`${packageName}/package.json`).version;
  for (const [label, config, burst, refill] of [
    ['defaults', {}, 100, 10],
    ['custom', { rate_limiting: { events_per_second: 20, events_burst_limit: 200 } }, 200, 20],
  ]) {
    test(`${version} public init/capture: ${label} burst ${burst}, refill ${refill}, drop and warning`, () => {
      const fixture = browser(packageName, config);
      try {
        const accepted = Array.from({ length: burst + 5 }, (_, index) => fixture.sdk.capture('synthetic_video_progress', { index }));
        assert.equal(accepted.filter(Boolean).length, burst);
        assert.equal(fixture.seen.filter(event => event.event === 'synthetic_video_progress').length, burst);
        assert.equal(fixture.seen.filter(event => event.event === '$$client_ingestion_warning').length, 1);
        fixture.advance(1000);
        assert.equal(Array.from({ length: refill + 1 }, () => fixture.sdk.capture('synthetic_after_refill')).filter(Boolean).length, refill);
        assert.equal(fixture.seen.filter(event => event.event === 'synthetic_video_progress').length, burst);
        fixture.advance(3600000);
        assert.equal(Array.from({ length: burst + 1 }, () => fixture.sdk.capture('synthetic_capped_refill')).filter(Boolean).length, burst);
      } finally { fixture.close(); }
    });
  }
  test(`${version} storage survives simulated reload; memory persistence resets`, () => {
    const first = browser(packageName);
    let second;
    try {
      for (let index = 0; index < 100; index++) assert.ok(first.sdk.capture('synthetic_deplete'));
      const stored = Object.fromEntries(Object.keys(first.window.localStorage).map(key => [key, first.window.localStorage.getItem(key)]));
      second = browser(packageName, {}, stored);
      assert.equal(second.sdk.capture('synthetic_reload'), undefined);
      second.advance(1000);
      assert.equal(Array.from({ length: 11 }, () => second.sdk.capture('synthetic_reload_refill')).filter(Boolean).length, 10);
    } finally { first.close(); second?.close(); }
    const memory = browser(packageName, { persistence: 'memory' });
    try {
      assert.equal(Array.from({ length: 101 }, () => memory.sdk.capture('synthetic_memory_deplete')).filter(Boolean).length, 100);
    } finally { memory.close(); }
    const reloadedMemory = browser(packageName, { persistence: 'memory' });
    try {
      assert.equal(Array.from({ length: 101 }, () => reloadedMemory.sdk.capture('synthetic_memory_reload')).filter(Boolean).length, 100);
    } finally { reloadedMemory.close(); }
  });
  test(`${version} real RateLimiter module with mocked persistence and fractional refill`, context => {
    context.mock.timers.enable({ apis: ['Date'], now: 1793660400000 });
    const { RateLimiter } = require(`${packageName}/lib/src/rate-limiter.js`);
    const values = {};
    const instance = { config: {}, persistence: { get_property: key => values[key], set_property: (key, value) => { values[key] = value; } }, capture: () => ({}) };
    const limiter = new RateLimiter(instance);
    for (let index = 0; index < 100; index++) assert.equal(limiter.clientRateLimitContext().isRateLimited, false);
    assert.equal(limiter.clientRateLimitContext().isRateLimited, true);
    context.mock.timers.tick(100);
    assert.equal(limiter.clientRateLimitContext().isRateLimited, false);
  });
  test(`${version} simulated simultaneous tabs do not share an atomic token bucket`, () => {
    const first = browser(packageName);
    const second = browser(packageName);
    try {
      assert.equal(Array.from({ length: 101 }, () => first.sdk.capture('synthetic_tab_a')).filter(Boolean).length, 100);
      assert.equal(Array.from({ length: 101 }, () => second.sdk.capture('synthetic_tab_b')).filter(Boolean).length, 100);
    } finally { first.close(); second.close(); }
  });
  test(`${version} unset string/array, current identity, invalid values, never mode and exhausted bucket`, () => {
    const fixture = browser(packageName);
    try {
      fixture.sdk.identify('synthetic-person-test');
      fixture.sdk.setPersonProperties({ synthetic_pii: 'FAKE_ONLY', keep: 'synthetic_keep' });
      fixture.sdk.unsetPersonProperties('synthetic_pii');
      const unset = fixture.seen.find(event => event.event === '$set' && event.properties.$unset);
      assert.deepEqual(unset.properties.$unset, ['synthetic_pii']);
      assert.equal(unset.properties.distinct_id, 'synthetic-person-test');
      assert.equal(unset.properties.$process_person_profile, true);
      fixture.sdk.unsetPersonProperties(['keep', '', null]);
      assert.deepEqual(fixture.seen.at(-1).properties.$unset, ['keep']);
      const length = fixture.seen.length;
      fixture.sdk.unsetPersonProperties([]);
      fixture.sdk.unsetPersonProperties('');
      assert.equal(fixture.seen.length, length);
      fixture.sdk.set_config({ person_profiles: 'never' });
      fixture.sdk.unsetPersonProperties('keep');
      assert.equal(fixture.seen.length, length);
      fixture.sdk.set_config({ person_profiles: 'identified_only' });
      for (let index = 0; index < 110; index++) fixture.sdk.capture('synthetic_deplete');
      const unsets = fixture.seen.filter(event => event.properties.$unset).length;
      fixture.sdk.unsetPersonProperties('keep');
      assert.equal(fixture.seen.filter(event => event.properties.$unset).length, unsets);
    } finally { fixture.close(); }
  });
  test(`${version} unset without identify enables processing for the current anonymous ID`, () => {
    const fixture = browser(packageName);
    try {
      const distinctId = fixture.sdk.get_distinct_id();
      fixture.sdk.unsetPersonProperties('synthetic_pii');
      const event = fixture.seen.find(event => event.properties.$unset);
      assert.equal(event.properties.distinct_id, distinctId);
      assert.equal(event.properties.$process_person_profile, true);
    } finally { fixture.close(); }
  });
}
