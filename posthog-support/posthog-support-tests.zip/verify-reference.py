import json
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

with open('evidence.json') as source:
    evidence = json.load(source)

for timestamp, local_date, expected_ny, expected_utc in evidence['cases']:
    instant = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
    local = instant.astimezone(ZoneInfo('America/New_York'))
    assert local.date().isoformat() == local_date, timestamp
    assert local.isoweekday() == expected_ny, timestamp
    assert instant.isoweekday() == expected_utc, timestamp

print(f'PASS: Python {sys.version.split()[0]} zoneinfo independently verified all 16 dates and 32 weekday values.')
