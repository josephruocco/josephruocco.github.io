import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
import { cases, counts } from './weekday-data.mjs';

const require = createRequire(import.meta.url);
const packages = ['posthog-js', 'posthog-js-previous'].map(name => {
  const metadata = require(`${name}/package.json`);
  return {
    package: name, version: metadata.version,
    files: ['lib/src/rate-limiter.js', 'lib/src/posthog-core.js', 'dist/array.no-external.js'].map(file => ({
      file, sha256: createHash('sha256').update(readFileSync(require.resolve(`${name}/${file}`))).digest('hex'),
    })),
  };
});
writeFileSync('evidence.json', JSON.stringify({ checkedAt: new Date().toISOString(), node: process.version, icu: process.versions.icu, tzdata: process.versions.tz, packages, cases, expected: { America_New_York: counts('America/New_York'), UTC: counts('UTC') } }, null, 2) + '\n');
console.log('Saved exact SDK artifact hashes and independent reference cases to evidence.json');
